
i=1
for nombre in *.DAT
	do
	echo "$((i++))  $nombre"
	done
